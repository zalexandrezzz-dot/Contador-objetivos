# Contador de Objetivos — Android

Projeto Android nativo com widget de tela inicial.

## Objetivos configurados
- Taxa vaga: R$ 743,82 restantes — vence 08/10/2026
- Objetivo 2: R$ 520,00 restantes — vence 13/10/2026
- MOTO: R$ 1.000,00 restantes — vence 14/10/2026

O widget permite registrar rapidamente R$20, R$40 ou R$60 em cada objetivo. O app permite qualquer outro valor.

## Como instalar/compilar
Abra a pasta no Android Studio, deixe o Gradle sincronizar e gere o APK. Depois instale no celular e adicione o widget "Contador de Objetivos" à tela inicial.

Observação: este pacote é o projeto-fonte, não um APK pronto. O contador fica salvo no próprio aparelho.
