package com.alexandre.contadorobjetivos

import android.app.*
import android.appwidget.*
import android.content.*
import android.widget.RemoteViews

class GoalWidgetProvider:AppWidgetProvider(){
 override fun onUpdate(c:Context,m:AppWidgetManager,ids:IntArray){ids.forEach{update(c,m,it)}}
 override fun onReceive(c:Context,intent:Intent){
  super.onReceive(c,intent)
  if(intent.action==ACTION_PAY){
   val id=intent.getStringExtra("goal") ?: return; val value=intent.getDoubleExtra("value",0.0); GoalStore.goals.find{it.id==id}?.let{GoalStore.pay(c,it,value)}; updateAll(c)
  }
 }
 private fun update(c:Context,m:AppWidgetManager,id:Int){
  val r=RemoteViews(c.packageName,R.layout.widget)
  r.removeAllViews(R.id.widgetGoals)
  GoalStore.goals.forEach{g->
   val v=RemoteViews(c.packageName,R.layout.widget_goal); val rem=GoalStore.remaining(c,g); val days=GoalStore.days(g.due); val per=if(days>0) rem/days else rem
   v.setTextViewText(R.id.wName,g.name); v.setTextViewText(R.id.wRemain,GoalStore.money(rem)); v.setTextViewText(R.id.wMeta,if(rem<=0) "Objetivo atingido ✓" else "${days} dias • ${GoalStore.money(per)}/dia")
   v.setOnClickPendingIntent(R.id.w20,pending(c,g.id,20.0)); v.setOnClickPendingIntent(R.id.w40,pending(c,g.id,40.0)); v.setOnClickPendingIntent(R.id.w60,pending(c,g.id,60.0)); r.addView(R.id.widgetGoals,v)
  }
  m.updateAppWidget(id,r)
 }
 private fun pending(c:Context,id:String,value:Double):PendingIntent{val i=Intent(c,GoalWidgetProvider::class.java).setAction(ACTION_PAY).putExtra("goal",id).putExtra("value",value);return PendingIntent.getBroadcast(c,(id+value).hashCode(),i,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)}
 companion object{
  const val ACTION_PAY="com.alexandre.contadorobjetivos.PAY"
  fun updateAll(c:Context){val m=AppWidgetManager.getInstance(c); val ids=m.getAppWidgetIds(ComponentName(c,GoalWidgetProvider::class.java)); ids.forEach{GoalWidgetProvider().update(c,m,it)}}
 }
}
