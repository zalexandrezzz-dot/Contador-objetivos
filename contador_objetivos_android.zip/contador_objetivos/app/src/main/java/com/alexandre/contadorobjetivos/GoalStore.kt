package com.alexandre.contadorobjetivos

import android.content.Context
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

data class Goal(val id:String,val name:String,val due:String,val initial:Double,val defaultDaily:Double)

object GoalStore {
    val goals = listOf(
        Goal("vaga","Taxa vaga","2026-10-08",743.82,67.62),
        Goal("g2","Objetivo 2","2026-10-13",520.00,32.50),
        Goal("moto","MOTO","2026-10-14",1000.00,58.82)
    )
    private const val PREFS="goals"
    fun remaining(c:Context,g:Goal)=c.getSharedPreferences(PREFS,0).getFloat(g.id,g.initial.toFloat()).toDouble()
    fun pay(c:Context,g:Goal,value:Double){ val p=c.getSharedPreferences(PREFS,0); p.edit().putFloat(g.id, maxOf(0.0, remaining(c,g)-value).toFloat()).apply() }
    fun reset(c:Context,g:Goal){ c.getSharedPreferences(PREFS,0).edit().putFloat(g.id,g.initial.toFloat()).apply() }
    fun money(v:Double):String=NumberFormat.getCurrencyInstance(Locale("pt","BR")).format(v)
    fun days(due:String):Int{
        val fmt=SimpleDateFormat("yyyy-MM-dd",Locale.US); fmt.timeZone=TimeZone.getTimeZone("UTC")
        val d=fmt.parse(due) ?: return 0
        val now=Calendar.getInstance(TimeZone.getTimeZone("UTC")); now.set(Calendar.HOUR_OF_DAY,0);now.set(Calendar.MINUTE,0);now.set(Calendar.SECOND,0);now.set(Calendar.MILLISECOND,0)
        return maxOf(0, ((d.time-now.timeInMillis)/86400000L).toInt())
    }
}
