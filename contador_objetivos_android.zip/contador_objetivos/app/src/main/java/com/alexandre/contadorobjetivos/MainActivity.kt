package com.alexandre.contadorobjetivos

import android.app.*
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.*

class MainActivity:Activity(){
 override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_main);render()}
 override fun onResume(){super.onResume(); if(findViewById<LinearLayout>(R.id.goalsContainer)!=null) render()}
 private fun render(){
  val box=findViewById<LinearLayout>(R.id.goalsContainer); box.removeAllViews()
  val inf=LayoutInflater.from(this)
  GoalStore.goals.forEach{g->
   val v=inf.inflate(R.layout.goal_row,box,false); val rem=GoalStore.remaining(this,g); val days=GoalStore.days(g.due)
   v.findViewById<TextView>(R.id.name).text=g.name; v.findViewById<TextView>(R.id.remaining).text=GoalStore.money(rem)
   val per=if(days>0) rem/days else rem
   v.findViewById<TextView>(R.id.meta).text=if(rem<=0) "Objetivo atingido ✓" else "${days} dias restantes • ${GoalStore.money(per)}/dia • vence ${g.due.substring(8,10)}/${g.due.substring(5,7)}"
   v.findViewById<Button>(R.id.pay20).setOnClickListener{pay(g,20.0)}
   v.findViewById<Button>(R.id.pay40).setOnClickListener{pay(g,40.0)}
   v.findViewById<Button>(R.id.pay60).setOnClickListener{pay(g,60.0)}
   v.findViewById<Button>(R.id.payCustom).setOnClickListener{val e=v.findViewById<EditText>(R.id.custom); val x=e.text.toString().replace(".","").replace(",",".").toDoubleOrNull(); if(x!=null&&x>0){pay(g,x);e.text.clear()}else e.error="Digite um valor válido"}
   box.addView(v)
  }
 }
 private fun pay(g:Goal,v:Double){GoalStore.pay(this,g,v);GoalWidgetProvider.updateAll(this);render()}
}
